# Let's Code React-Native

## [Watch it on YouTube](http://bit.ly/ByProgrammersYT)

In this episode of "Let’s Code React Native" series, we are going to build a good looking Food Delivery App based on the design created by ILia on Dribbble.

Be sure to subscribe to our YouTube channel for more videos like this!

## Table of Contents

| Code | Project | Preview | Inspiration | No. of Screens |
| ------ | ------ | ------ | ------ | ------ |
| LCRN08 | [Food Delivery App](https://youtu.be/diUDjNwZ8Lg) | <img src="https://cdn.dribbble.com/users/1716131/screenshots/14527824/media/c490abc83e617dcfca83cb67ebf279a1.png?compress=1&resize=1200x900" width="120" /> | [View](https://dribbble.com/shots/14527824-Food-Delivery-Mobile-App) | 3 |

## Contributors

<a href="https://github.com/byprogrammers/lets-code-react-native/graphs/contributors">
  <img src="https://contributors-img.web.app/image?repo=byprogrammers/lets-code-react-native" />
</a>

